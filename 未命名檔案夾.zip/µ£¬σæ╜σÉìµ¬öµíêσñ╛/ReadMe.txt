A simple sample using basic display APIs to output text and background images.
